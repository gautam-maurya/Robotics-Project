#! /usr/bin/env python

import rospy
from geometry_msgs.msg import Twist
from time import sleep

rospy.init_node('move_bot')

publisher = rospy.Publisher('/cmd_vel',Twist,queue_size=1)

rr = True

while not rospy.is_shutdown():
    msg = Twist()
    msg.angular.z = 0.5 if rr else -0.5
    publisher.publish(msg)
    msg.linear.x = 0.5 if rr else -0.5
    publisher.publish(msg)

    rospy.loginfo("Other")
    rr = not rr
    sleep(15)